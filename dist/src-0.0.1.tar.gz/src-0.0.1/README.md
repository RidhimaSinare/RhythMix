A simple Music Recommendation System WebApp made as Web technology Mini-Project.

Implementing:
    1. EDA Based clustering model
    2. Flask based deployment
    3. MLOps flow and Data Version Control